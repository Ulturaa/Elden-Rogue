import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;

public class CharCreateController {

    private CharCreateModel ccm;
    private CharCreateView ccv;

    /**
     * This is the constructor of the CharCreateController Class
     * 
     * @param ccm is the model
     * @param ccv is the view
     * 
     */

    public CharCreateController(CharCreateModel ccm, CharCreateView ccv) {
        this.ccm = ccm;
        this.ccv = ccv;

        ccv.setCCLabel("NAME:");
        ccv.setCCLabel("JOB CLASS:");
        ccv.setCCLabel("LEVEL:");
        ccv.setCCLabel("HP:");
        ccv.setCCLabel("ENDURANCE:");
        ccv.setCCLabel("DEXTERITY:");
        ccv.setCCLabel("STRENGTH:");
        ccv.setCCLabel("INTELLIGENCE:");
        ccv.setCCLabel("FAITH:");

        ccv.composeCCLabels();

        ccv.setCCButton("Input Name", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("FOR INPUTTING NAME");
                String pName = null;
                boolean runit = true;

                ccv.getuserNameInput();
                if(ccv.getnameInput() == null || ccv.getnameInput().isEmpty()) {
                    System.out.println("Name null or empty");
                } else {
                    pName = ccv.getnameInput();
                    ccm.setName(pName);
                    ccm.setCharacterName();
                    pName = ccm.getCharacterName();
                    ccv.updateLabel(0, "NAME: " + pName);
                }
            }
        });

        ccv.setCCButton("Select Job Class", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // System.out.println("To Character Creation.");
                ccv.showJobchoices();
                String job = ccv.getSelectedJob();
                System.out.println(job);
                
                if(job != null) {
                    ccm.setJobClass(job);
                    ccm.setStats(ccm.getJobClass());
                    ccv.updateLabel(1, "JOB CLASS: " + ccm.getJobClass());
                    ccv.updateLabel(2, "LEVEL: " + ccm.getLevel());
                    ccv.updateLabel(3, "HP: " + ccm.getstat(0));
                    ccv.updateLabel(4, "ENDURANCE: " + ccm.getstat(1));
                    ccv.updateLabel(5, "DEXTERITY: " + ccm.getstat(2));
                    ccv.updateLabel(6, "STRENGTH: " + ccm.getstat(3));
                    ccv.updateLabel(7, "INTELLIGENCE: " + ccm.getstat(4));
                    ccv.updateLabel(8, "FAITH: " + ccm.getstat(5));
                }
            }
        });

        ccv.setCCButton("Confirm", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Confirming");
                JLabel sysMessage = new JLabel();

                System.out.println(ccm.getCharacterName().isEmpty() + " " + ccm.getLevel());
                if (ccm.getCharacterName() == "" || ccm.getJobClass() == "Jobless") {
                    sysMessage = ccv.sysMessage("Please input BOTH NAME AND JOB CLASS");
                    System.out.println("Please input BOTH NAME AND JOB CLASS");
                } else {
                    ccv.closeFrame();
                    Character character = ccm.getCharacter();
                    LobbyModel lm = new LobbyModel(character);
                    LobbyView lv = new LobbyView();
                    LobbyController lc = new LobbyController(lm, lv);

                }
            }
        });

        ccv.setCCButton("Back", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ccv.closeFrame();
                Game game = new Game();
                // game.TitleScreen();
                game.cc();
                Character character = game.getCharacter();
                CharCreate charCreate = game.getCharCreate();
                TitleScreenModel tsm = new TitleScreenModel();
                TitleScreenView tsv = new TitleScreenView();
                TitleScreenController tsc = new TitleScreenController(tsv, tsm, character,
                        charCreate);
            }
        });

        ccv.composeCCButtonList();

    }
}
