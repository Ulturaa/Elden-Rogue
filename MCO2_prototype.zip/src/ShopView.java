import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

public class ShopView {
    private JFrame SFrame;
    private JLabel STitle;

    private ArrayList<JButton> SButtonlist = new ArrayList<JButton>();
    private ArrayList<JLabel> SLabellist = new ArrayList<JLabel>();
    private ArrayList<JPanel> WPanellist = new ArrayList<JPanel>();

    private ArrayList<JButton> SwordButtonlist = new ArrayList<JButton>();
    private ArrayList<JButton> KatanaButtonlist = new ArrayList<JButton>();
    private ArrayList<JButton> WhipButtonlist = new ArrayList<JButton>();
    private ArrayList<JButton> GreatSwordButtonlist = new ArrayList<JButton>();
    private ArrayList<JButton> StaffButtonlist = new ArrayList<JButton>();
    private ArrayList<JButton> SealButtonlist = new ArrayList<JButton>();

    private ArrayList<JScrollPane> ScrollList = new ArrayList<JScrollPane>();
    private ArrayList<JTextArea> WeaponTextList = new ArrayList<JTextArea>();

    private ArrayList<JLabel> wImageList = new ArrayList<JLabel>();

    /**
     * Constructs a ShopView and initializes the main frame of the shop UI.
     */
    public ShopView() {
        SFrame = new JFrame();
        SFrame.setSize(720, 480);
        SFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        SFrame.setLocationRelativeTo(null);
        SFrame.setResizable(false);
        SFrame.setLayout(new BoxLayout(SFrame.getContentPane(), BoxLayout.Y_AXIS));
        // SFrame.getContentPane().add(Box.createVerticalGlue());
        // SFrame.setLayout(new FlowLayout());
        SFrame.getContentPane().setBackground(Color.black);

        STitle = new JLabel("Shop");
        // STitle.setAlignmentX(JLabel.LEFT_ALIGNMENT); // Set horizontal alignment to
        // left
        // STitle.setAlignmentY(JLabel.TOP_ALIGNMENT);
        STitle.setHorizontalAlignment(SwingConstants.LEFT);
        STitle.setForeground(Color.YELLOW);
        STitle.setFont(new Font("Times New Roman", Font.BOLD, 40));
        STitle.setBounds(170, 20, 400, 60);

        // ImageIcon img = new ImageIcon(
        // new ImageIcon("Weapons/ShortSword.png").getImage().getScaledInstance(30, 30,
        // Image.SCALE_SMOOTH));
        // img.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        // JLabel ia = new JLabel();
        // ia.setText("hello");
        // ia.setIcon(img);

        SFrame.add(STitle);
        // SFrame.add(ia);
        SFrame.setVisible(true);

    }

    /**
     * Sets a button for the main shop actions
     *
     * @param btnLabel       The label text of the button.
     * @param actionListener The action listener to be associated with the button.
     */
    public void setSButton(String btnLabel, ActionListener actionListener) {
        JButton SButton = new JButton(btnLabel);
        SButton.addActionListener(actionListener);
        SButton.setPreferredSize(new Dimension(200, 30));

        SButtonlist.add(SButton);
    }

    /**
     * Composes the list of buttons into the shop UI.
     */
    public void composeSButtonlist() {
        Iterator<JButton> i = SButtonlist.iterator();

        while (i.hasNext()) {
            this.SFrame.add(i.next());
        }
    }

    /**
     * Sets a label with the specified text.
     *
     * @param s The text of the label.
     */
    public void setSLabel(String s) {
        JLabel SLabel = new JLabel();

        SLabel.setText(s);
        SLabel.setForeground(Color.YELLOW);
        SLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        SLabellist.add(SLabel);
    }

    /**
     * Composes the list of labels into the shop UI.
     */
    public void composeSLabels() {
        Iterator<JLabel> i = SLabellist.iterator();

        while (i.hasNext()) {
            this.SFrame.add(i.next());
        }

    }

    /**
     * Updates the label at the specified index with the new text.
     *
     * @param index   The index of the label to be updated.
     * @param newText The new text for the label.
     */
    public void updateLabel(int index, String newText) {
        if (index >= 0 && index < SLabellist.size()) {
            JLabel labelToUpdate = SLabellist.get(index);
            /// final String original = labelToUpdate.getText();
            labelToUpdate.setText(newText);

            SFrame.revalidate();
            SFrame.repaint();
        } else {
            System.out.println("Invalid index");
        }
    }

    /**
     * Sets the visibility of the shop UI.
     *
     * @param b True to set the shop UI visible, false otherwise.
     */
    public void setVisible(boolean b) {
        SFrame.setVisible(b);
    }

    /**
     * Sets the visibility of a specific button in the shop UI.
     *
     * @param i The index of the button.
     * @param b True to set the button visible, false otherwise.
     */
    public void setSButtonvisbility(int i, boolean b) {
        SButtonlist.get(i).setVisible(b);
    }

    /**
     * Sets a panel for displaying purchasable weapon option buttons.
     */
    public void setWPanel() {
        JPanel wpanel = new JPanel();

        wpanel.setLayout(new FlowLayout());
        wpanel.setBackground(Color.BLACK);
        wpanel.setVisible(false);

        WPanellist.add(wpanel);
    }

    /**
     * Composes the list of weapon panels into the shop UI.
     */
    public void composeWPanellist() {
        Iterator<JPanel> i = WPanellist.iterator();

        while (i.hasNext()) {
            this.SFrame.add(i.next());
        }
    }

    /**
     * Sets the visibility of a specific panel in the shop UI.
     *
     * @param i The index of the panel.
     * @param b True to set the panel visible, false otherwise.
     */
    public void setPanelVisible(int i, boolean b) {
        WPanellist.get(i).setVisible(b);
    }

    public void setSwordButton(String btnLabel, ActionListener actionListener) {
        JButton WButton = new JButton(btnLabel);
        WButton.addActionListener(actionListener);
        WButton.setPreferredSize(new Dimension(200, 30));

        SwordButtonlist.add(WButton);
    }

    public void setKatanaButton(String btnLabel, ActionListener actionListener) {
        JButton WButton = new JButton(btnLabel);
        WButton.addActionListener(actionListener);
        WButton.setPreferredSize(new Dimension(200, 30));

        KatanaButtonlist.add(WButton);
    }

    public void setWhipButton(String btnLabel, ActionListener actionListener) {
        JButton WButton = new JButton(btnLabel);
        WButton.addActionListener(actionListener);
        WButton.setPreferredSize(new Dimension(200, 30));

        WhipButtonlist.add(WButton);
    }

    public void setGreatSwordButton(String btnLabel, ActionListener actionListener) {
        JButton WButton = new JButton(btnLabel);
        WButton.addActionListener(actionListener);
        WButton.setPreferredSize(new Dimension(200, 30));

        GreatSwordButtonlist.add(WButton);
    }

    public void setStaffButton(String btnLabel, ActionListener actionListener) {
        JButton WButton = new JButton(btnLabel);
        WButton.addActionListener(actionListener);
        WButton.setPreferredSize(new Dimension(200, 30));

        StaffButtonlist.add(WButton);
    }

    public void setSealButton(String btnLabel, ActionListener actionListener) {
        JButton WButton = new JButton(btnLabel);
        WButton.addActionListener(actionListener);
        WButton.setPreferredSize(new Dimension(200, 30));

        SealButtonlist.add(WButton);
    }

    /**
     * Adds buttons corresponding to a specific weapon type to a panel.
     *
     * @param j    The index of the panel.
     * @param type The type of weapon (1 for Sword, 2 for Katana, etc.).
     */
    public void addtoPanel(int j, int type) {
        Iterator<JButton> i = SwordButtonlist.iterator();
        switch (type) {
            case 1:
                i = SwordButtonlist.iterator();
                break;
            case 2:
                i = KatanaButtonlist.iterator();
                break;
            case 3:
                i = WhipButtonlist.iterator();
                break;
            case 4:
                i = GreatSwordButtonlist.iterator();
                break;
            case 5:
                i = StaffButtonlist.iterator();
                break;
            case 6:
                i = SealButtonlist.iterator();
                break;

        }
        while (i.hasNext()) {
            this.WPanellist.get(j).add(i.next());
        }
    }

    /**
     * Sets the visibility of a specific label in the shop UI.
     *
     * @param i The index of the label.
     * @param b True to set the label visible, false otherwise.
     */
    public void setVisibleLabel(int i, boolean b) {
        SLabellist.get(i).setVisible(b);
    }

    /**
     * Sets up a scroll pane for displaying weapon information.
     */
    public void setScroll() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBackground(Color.BLACK);
        scrollPane.setPreferredSize(new Dimension(600, 200));

        ScrollList.add(scrollPane);
    }

    /**
     * Adds a scroll pane to a specific panel in the shop UI.
     *
     * @param j The index of the panel.
     * @param k The index of the scroll pane.
     */
    public void addScrolltoPanel(int j, int k) {
        WPanellist.get(j).add(ScrollList.get(k));

    }

    /**
     * Sets the visibility of a specific scroll pane in the shop UI.
     *
     * @param i The index of the scroll pane.
     * @param b True to set the scroll pane visible, false otherwise.
     */
    public void setVisibleScroll(int i, boolean b) {
        ScrollList.get(i).setVisible(b);
    }

    /**
     * Sets up a text area for displaying weapon information.
     *
     * @param s The text to be displayed.
     */
    public void setWText(String s) {
        JTextArea WText = new JTextArea();

        WText.setText(s);
        WText.setBackground(Color.BLACK);
        WText.setForeground(Color.YELLOW);
        WText.setFont(new Font("Times New Roman", Font.BOLD, 15));
        WText.setWrapStyleWord(true);
        WText.setLineWrap(true);

        WeaponTextList.add(WText);
        // scrollPane.setViewportView(WText);
        // WLabellist.add(WText);
    }

    /**
     * Adds a text area to a specific scroll pane in the shop UI.
     *
     * @param j The index of the panel.
     * @param k The index of the text area.
     */
    public void addTexttoScroll(int j, int k) {
        // Iterator<JTextArea> i = WeaponTextList.iterator();

        // while (i.hasNext()) {
        this.ScrollList.get(j).setViewportView(WeaponTextList.get(k));
        // WPanellist.get(j).add(WeaponTextList.get(k));
        // ScrollList.get(j).setViewportView(WPanellist.get(j));
        SFrame.revalidate();
        SFrame.repaint();
        // }
    }

    /**
     * Sets up an image for displaying a weapon with its name.
     *
     * @param s The path to the image file.
     * @param n The name of the weapon.
     */
    public void setWeaponImage(String s, String n) {
        ImageIcon wImage = new ImageIcon(new ImageIcon(s).getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH));

        JLabel wIMG = new JLabel();
        wIMG.setIcon(wImage);
        wIMG.setText(n);
        wIMG.setForeground(Color.YELLOW);
        wIMG.setFont(new Font("Times New Roman", Font.BOLD, 10));
        wIMG.setHorizontalTextPosition(JLabel.RIGHT);
        wIMG.setVerticalTextPosition(JLabel.CENTER);
        // JLabel wIMG = new JLabel(s);
        wImageList.add(wIMG);
    }

    public void addImagetoScroll(int j, int k) {
        // JPanel viewportPanel = new JPanel(new FlowLayout());
        // viewportPanel.add(wImageList.get(k));
        // JScrollPane scrollPane = ScrollList.get(j);
        // scrollPane.setViewportView(viewportPanel);

        ScrollList.get(j).setViewportView(wImageList.get(k));

        SFrame.revalidate();
        SFrame.repaint();
    }

    /**
     * Adds an image of a weapon with its name to a specific panel in the shop UI.
     *
     * @param j The index of the panel.
     * @param k The index of the image.
     */
    public void addImagetoPanel(int j, int k) {
        WPanellist.get(j).add(wImageList.get(k));
    }

}
